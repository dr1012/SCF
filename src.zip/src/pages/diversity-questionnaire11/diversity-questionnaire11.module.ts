import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire11Page } from './diversity-questionnaire11';

@NgModule({
  declarations: [
    DiversityQuestionnaire11Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire11Page),
  ],
})
export class DiversityQuestionnaire11PageModule {}
