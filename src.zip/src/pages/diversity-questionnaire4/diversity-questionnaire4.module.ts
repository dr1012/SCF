import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire4Page } from './diversity-questionnaire4';

@NgModule({
  declarations: [
    DiversityQuestionnaire4Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire4Page),
  ],
})
export class DiversityQuestionnaire4PageModule {}
