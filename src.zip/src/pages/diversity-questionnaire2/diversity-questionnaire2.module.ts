import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire2Page } from './diversity-questionnaire2';

@NgModule({
  declarations: [
    DiversityQuestionnaire2Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire2Page),
  ],
})
export class DiversityQuestionnaire2PageModule {}
