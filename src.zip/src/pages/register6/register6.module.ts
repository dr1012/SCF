import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Register6Page } from './register6';

@NgModule({
  declarations: [
    Register6Page,
  ],
  imports: [
    IonicPageModule.forChild(Register6Page),
  ],
})
export class Register6PageModule {}
