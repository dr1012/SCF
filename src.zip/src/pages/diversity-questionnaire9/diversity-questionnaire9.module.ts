import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire9Page } from './diversity-questionnaire9';

@NgModule({
  declarations: [
    DiversityQuestionnaire9Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire9Page),
  ],
})
export class DiversityQuestionnaire9PageModule {}
