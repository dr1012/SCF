import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Graph2Page } from './graph2';

@NgModule({
  declarations: [
    Graph2Page,
  ],
  imports: [
    IonicPageModule.forChild(Graph2Page),
  ],
})
export class Graph2PageModule {}
