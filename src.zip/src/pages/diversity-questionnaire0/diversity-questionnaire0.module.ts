import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire0Page } from './diversity-questionnaire0';

@NgModule({
  declarations: [
    DiversityQuestionnaire0Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire0Page),
  ],
})
export class DiversityQuestionnaire0PageModule {}
