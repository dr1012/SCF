import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire5Page } from './diversity-questionnaire5';

@NgModule({
  declarations: [
    DiversityQuestionnaire5Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire5Page),
  ],
})
export class DiversityQuestionnaire5PageModule {}
