import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire9Page } from './questionnaire9';

@NgModule({
  declarations: [
    Questionnaire9Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire9Page),
  ],
})
export class Questionnaire9PageModule {}
