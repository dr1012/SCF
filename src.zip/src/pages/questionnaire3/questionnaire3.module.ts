import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire3Page } from './questionnaire3';

@NgModule({
  declarations: [
    Questionnaire3Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire3Page),
  ],
})
export class Questionnaire3PageModule {}
