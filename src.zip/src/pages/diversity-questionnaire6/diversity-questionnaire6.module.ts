import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire6Page } from './diversity-questionnaire6';

@NgModule({
  declarations: [
    DiversityQuestionnaire6Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire6Page),
  ],
})
export class DiversityQuestionnaire6PageModule {}
