import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire8Page } from './diversity-questionnaire8';

@NgModule({
  declarations: [
    DiversityQuestionnaire8Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire8Page),
  ],
})
export class DiversityQuestionnaire8PageModule {}
