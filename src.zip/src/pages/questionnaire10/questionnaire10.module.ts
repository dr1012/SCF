import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire10Page } from './questionnaire10';

@NgModule({
  declarations: [
    Questionnaire10Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire10Page),
  ],
})
export class Questionnaire10PageModule {}
