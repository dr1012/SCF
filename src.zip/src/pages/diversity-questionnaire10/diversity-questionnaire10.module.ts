import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire10Page } from './diversity-questionnaire10';

@NgModule({
  declarations: [
    DiversityQuestionnaire10Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire10Page),
  ],
})
export class DiversityQuestionnaire10PageModule {}
