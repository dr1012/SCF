import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire2Page } from './questionnaire2';

@NgModule({
  declarations: [
    Questionnaire2Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire2Page),
  ],
})
export class Questionnaire2PageModule {}
