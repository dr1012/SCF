import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire1Page } from './diversity-questionnaire1';

@NgModule({
  declarations: [
    DiversityQuestionnaire1Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire1Page),
  ],
})
export class DiversityQuestionnaire1PageModule {}
