import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire4Page } from './questionnaire4';

@NgModule({
  declarations: [
    Questionnaire4Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire4Page),
  ],
})
export class Questionnaire4PageModule {}
