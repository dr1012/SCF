import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire1Page } from './questionnaire1';

@NgModule({
  declarations: [
    Questionnaire1Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire1Page),
  ],
})
export class Questionnaire1PageModule {}
