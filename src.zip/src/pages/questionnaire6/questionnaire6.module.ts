import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire6Page } from './questionnaire6';

@NgModule({
  declarations: [
    Questionnaire6Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire6Page),
  ],
})
export class Questionnaire6PageModule {}
