import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire3Page } from './diversity-questionnaire3';

@NgModule({
  declarations: [
    DiversityQuestionnaire3Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire3Page),
  ],
})
export class DiversityQuestionnaire3PageModule {}
