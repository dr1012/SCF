import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire7Page } from './questionnaire7';

@NgModule({
  declarations: [
    Questionnaire7Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire7Page),
  ],
})
export class Questionnaire7PageModule {}
