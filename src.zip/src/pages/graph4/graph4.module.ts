import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Graph4Page } from './graph4';

@NgModule({
  declarations: [
    Graph4Page,
  ],
  imports: [
    IonicPageModule.forChild(Graph4Page),
  ],
})
export class Graph4PageModule {}
