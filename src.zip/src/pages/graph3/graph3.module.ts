import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Graph3Page } from './graph3';

@NgModule({
  declarations: [
    Graph3Page,
  ],
  imports: [
    IonicPageModule.forChild(Graph3Page),
  ],
})
export class Graph3PageModule {}
