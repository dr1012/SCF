import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionnaire11Page } from './questionnaire11';

@NgModule({
  declarations: [
    Questionnaire11Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionnaire11Page),
  ],
})
export class Questionnaire11PageModule {}
