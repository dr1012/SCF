import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DiversityQuestionnaire7Page } from './diversity-questionnaire7';

@NgModule({
  declarations: [
    DiversityQuestionnaire7Page,
  ],
  imports: [
    IonicPageModule.forChild(DiversityQuestionnaire7Page),
  ],
})
export class DiversityQuestionnaire7PageModule {}
