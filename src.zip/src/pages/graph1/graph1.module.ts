import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Graph1Page } from './graph1';

@NgModule({
  declarations: [
    Graph1Page,
  ],
  imports: [
    IonicPageModule.forChild(Graph1Page),
  ],
})
export class Graph1PageModule {}
