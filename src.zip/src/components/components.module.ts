import { NgModule } from '@angular/core';
import { TapRevealComponent } from './tap-reveal/tap-reveal';
@NgModule({
	declarations: [TapRevealComponent],
	imports: [],
	exports: [TapRevealComponent]
})
export class ComponentsModule {}
